# Set working directory first:
setwd("C:/Users/USER/OneDrive - Sri Lanka Institute of Information Technology/Desktop/IT24101181")

# Question 1
n1 <- 44; p1 <- 0.92
p_eq_40 <- dbinom(40, n1, p1)
p_le_35 <- pbinom(35, n1, p1)
p_ge_38 <- 1 - pbinom(37, n1, p1)
p_40_42 <- sum(dbinom(40:42, n1, p1))

# Question 2 (Poisson)
lam2 <- 5
p_poisson_6 <- dpois(6, lam2)
p_poisson_gt6 <- 1 - ppois(6, lam2)

# Exercise 1
n3 <- 50; p3 <- 0.85
p_ge_47 <- 1 - pbinom(46, n3, p3)

# Exercise 2
lam4 <- 12
p_poisson_15 <- dpois(15, lam4)

# Print (increase digits if you want)
options(digits=8)
p_eq_40; p_le_35; p_ge_38; p_40_42
p_poisson_6; p_poisson_gt6
p_ge_47
p_poisson_15
